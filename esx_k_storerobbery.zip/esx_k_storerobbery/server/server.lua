ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

if Config.EnableItemTrigger then

	ESX.RegisterUsableItem(Config.LockpickItem, function(source)
		TriggerClientEvent('k_kaupparosto:itemused', source)
	end)

	RegisterServerEvent('k_kaupparosto:fail')
	AddEventHandler('k_kaupparosto:fail', function()
		local _source = source
		local xPlayer = ESX.GetPlayerFromId(_source)

		xPlayer.removeInventoryItem(Config.LockpickItem, 1)
	end)

end

RegisterServerEvent('k_kaupparosto:getitems')
AddEventHandler('k_kaupparosto:getitems', function()
	local xPlayer = ESX.GetPlayerFromId(source)
	local itemi = math.random(1,#Config.Items)
	local ase = math.random(1,#Config.Guns)
	local poijjaatmatikkaavittu = math.random(1,100)
	local kuinkapaljonhaluut = math.random(1,5)
	xPlayer.addInventoryItem(Config.Items[itemi], kuinkapaljonhaluut)


	if poijjaatmatikkaavittu < 50 then
		local itemi = math.random(1,#Config.Items)
		xPlayer.addInventoryItem(Config.Items[itemi], kuinkapaljonhaluut)
		TriggerClientEvent('esx:showNotification', source, _U('found_item'))
	end

	if Config.Guns then
		if poijjaatmatikkaavittu  < 10 then
			xPlayer.addWeapon(Config.Guns[ase], 42)
			TriggerClientEvent('esx:showNotification', source, _U('found_gun'))
		end
	end

	local xPlayers = ESX.GetPlayers()
	for i=1, #xPlayers, 1 do
		local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		if xPlayer.job.name == 'police' then
			TriggerClientEvent('k_kaupparosto:onnistu', xPlayers[i], pos)
		end
	end

end)


RegisterServerEvent('k_kaupparosto:keskeytetty')
AddEventHandler('k_kaupparosto:keskeytetty', function()
	local source = source
	local xPlayer = ESX.GetPlayerFromId(source)
	local xPlayers = ESX.GetPlayers()

	for i=1, #xPlayers, 1 do
		local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		if xPlayer.job.name == 'police' then
			TriggerClientEvent('k_kaupparosto:keskeytetty', xPlayers[i])
		end
	end
end)

RegisterServerEvent('k_kaupparosto:ReceiveMonies')
AddEventHandler('k_kaupparosto:ReceiveMonies', function(check)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)

	if check == true then
		local amount = math.random(Config.CashMin,Config.CashMax)
		xPlayer.addMoney(amount)
		--TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'error', text = _U('complete'), style = { ['background-color'] = '#0fb504', ['color'] = '#FFFFFF' } })
		TriggerClientEvent('esx:showNotification', source, _U('complete'))
	end
	
end)

RegisterServerEvent('k_kaupparosto:cops', robtype, store)
AddEventHandler('k_kaupparosto:cops', function(robtype, store)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local xPlayers = ESX.GetPlayers()

	local locationLastRobbed

	local cops = 0
	for i=1, #xPlayers, 1 do
		local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		if xPlayer.job.name == 'police' then
			cops = cops + 1
		end
	end

	if Config.SafeLocationss[store] then
		locationLastRobbed = Config.SafeLocationss[store]
	end

	if robtype == "cashreg" then
		if cops >= Config.Police then
			if (os.time() - locationLastRobbed.lastRobbed) < Config.CooldownSeconds and locationLastRobbed.lastRobbed ~= 0 then 
				TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'error', text = _U('empty'), style = { ['background-color'] = '#B22222', ['color'] = '#FFFFFF' } })
			else
				TriggerClientEvent('k_kaupparosto:cashregrob', source)
			end
		else
			TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'error', text = _U('no_police'), style = { ['background-color'] = '#0048ba', ['color'] = '#FFFFFF' } })
		end
	end
end)

RegisterServerEvent('k_kaupparosto:completed', store)
AddEventHandler('k_kaupparosto:completed', function(store)
	local locationRobbed
	if Config.SafeLocationss[store] then
		locationRobbed = Config.SafeLocationss[store]
		locationRobbed.lastRobbed = os.time()
	end
end)

RegisterServerEvent('k_kaupparosto:notify')
AddEventHandler('k_kaupparosto:notify', function(type, store)
	local xPlayer = ESX.GetPlayerFromId(_source)
	local xPlayers = ESX.GetPlayers()
	local locationblip

	if Config.SafeLocationss[store] then
		locationblip = Config.SafeLocationss [store]
	end

	for i=1, #xPlayers, 1 do
		local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		if xPlayer.job.name == 'police' then
			if type == 1 then
				TriggerClientEvent('k_kaupparosto:drawblip', xPlayers[i], locationblip.coords)
			elseif type == 2 then
				TriggerClientEvent('k_kaupparosto:removeblip', xPlayers[i])
			end
		end
	end
end)