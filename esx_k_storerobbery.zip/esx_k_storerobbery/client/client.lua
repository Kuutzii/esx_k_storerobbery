local robbing = false
local robbinglocation = nil
local camera = nil
local robbinglocation2 = nil
local blip
ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

function InCashRegZone(coords)
    Location = Config.SafeLocationss
    for i = 1, #Location, 1 do
        if GetDistanceBetweenCoords(coords, Location[i].coords.x, Location[i].coords.y, Location[i].coords.z, true) < 1.5 then
        	robbinglocation = Location[i].name
			if Config.Roasdasd then
        		camera = Location[i].cam
        	end
            return true
        end
    end
end

RegisterNetEvent('k_kaupparosto:drawblip')
AddEventHandler('k_kaupparosto:drawblip', function(coords)
	ESX.ShowAdvancedNotification(_U('alarm_name'), _U('triggered'), "", "CHAR_CALL911", 1)
	PlaySound(-1, "Event_Start_Text", "GTAO_FM_Events_Soundset", 0, 0, 1)
	RemoveBlip(blip)
	blip = AddBlipForCoord(coords.x, coords.y, coords.z)
	SetBlipSprite(blip, 59)
	SetBlipScale(blip, 1.0)
	SetBlipColour(blip, 1)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(_U('blip_map'))
    EndTextCommandSetBlipName(blip)
end)

RegisterNetEvent('k_kaupparosto:removeblip')
AddEventHandler('k_kaupparosto:removeblip', function()
	RemoveBlip(blip)
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
		if not Config.EnableItemTrigger then
			player = GetPlayerPed(-1)
			coords = GetEntityCoords(player)

			if Config.donttouch then
				if InCashRegZone(coords) then
					if IsControlJustReleased(0, Config.Control) and IsInputDisabled(0) then
						TriggerServerEvent('k_kaupparosto:cops', "cashreg", robbinglocation2)
					end
				end
			end
		end
	end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        player = GetPlayerPed(-1)
        coords = GetEntityCoords(player)

        if Config.donttouch then
	        for k, v in pairs(Config.SafeLocationss) do
	            if GetDistanceBetweenCoords(coords, Config.SafeLocationss[k].coords.x, Config.SafeLocationss[k].coords.y, Config.SafeLocationss[k].coords.z, true) < 1.5  then
	                if not Config.EnableItemTrigger then
						ESX.Game.Utils.DrawText3D(vector3(Config.SafeLocationss[k].coords.x, Config.SafeLocationss[k].coords.y, Config.SafeLocationss[k].coords.z + 1.0), _U('rob_key'), 0.4)
					end
					robbinglocation2 = k
	            end
	        end
		end
	end
end)

RegisterNetEvent('k_kaupparosto:cashregrob')
AddEventHandler('k_kaupparosto:cashregrob', function()
	player = GetPlayerPed(-1)
    coords = GetEntityCoords(player)
	if Config.NotifyPolice then
		if Config.Roasdasd then
		TriggerServerEvent('k_kaupparosto:notify', 1, robbinglocation2)
	end
	ESX.ShowNotification(_U('key_inform'))
	--Citizen.Wait(200)
	local res = exports['esx_k_storerobbery']:createSafe({math.random(0,99), math.random(0,99), math.random(0,99)})
	if res == true then
		local player = GetPlayerFromServerId(source)
		TriggerServerEvent('k_kaupparosto:notify', 2)
		TriggerServerEvent('k_kaupparosto:ReceiveMonies', res)
		if Config.Cooldown then
			TriggerServerEvent('k_kaupparosto:completed', robbinglocation2)
			TriggerServerEvent('k_kaupparosto:getitems', robbinglocation2)
		end
	else
		exports['mythic_notify']:DoHudText('error', _U('faill'))
		TriggerServerEvent('k_kaupparosto:notify', 2)
		if Config.EnableItemTrigger then
			TriggerServerEvent('k_kaupparosto:fail')
		end
	end
end
end)

if Config.EnableItemTrigger then
	RegisterNetEvent('k_kaupparosto:itemused')
	AddEventHandler('k_kaupparosto:itemused', function()
		print("here")
		player = GetPlayerPed(-1)
		coords = GetEntityCoords(player)

		if Config.donttouch then
			if InCashRegZone(coords) then
				TriggerServerEvent('k_kaupparosto:cops', "cashreg", robbinglocation2)
			end
		end
	end)
end

function DrawText3D(x,y,z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end
