fx_version 'cerulean'
games { 'gta5' }

authot 'kuutzii#8107'
version '1.0'

lua54 'yes'

client_scripts { 
	'@es_extended/locale.lua',
	"config.lua",
	"client/client.lua",
	"locales/en.lua",
	"locales/fi.lua",
	"pd-safe/pd-safe.lua"
}

server_scripts {
	'@es_extended/locale.lua',
	"locales/en.lua",
	"locales/fi.lua",
	"config.lua",
	"server/server.lua"
}

dependencies {
	'mythic_notify'
}
