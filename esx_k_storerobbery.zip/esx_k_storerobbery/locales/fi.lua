Locales['fi'] = {
    ['key_inform'] = '[A] JA [D] Liikuttaaksesi. [W] Hyväksy, [S] Peruuta',
    ['faill'] = 'Epäonnistuit',
    ['empty'] = 'Kassakaappi on tyhjä',
    ['no_police'] = 'Ei tarpeeksi poliiseja',
    ['rob_key'] = '~r~[E]~s~ Ryöstä',
    ['blip_map'] = 'Kauppa Ryöstö(Actiivinen)',
    ['alarm_name'] = 'Kauppa Ryöstö',
    ['triggered'] = 'Hälytys laukaistu!!',
    ['found_item'] = '~g~[Hienoa]~w~Löysit tavaraa',
    ['found_gun'] = '~g~[Hienoa]~w~Löysit aseen',
    ['complete'] = '~g~[Hienoa]~w~Löysit rahaa'
}