Locales['en'] = {
    ['key_inform'] = '[A] AND [D] To move. [W] Accept, [S] Cancel',
    ['fail'] = 'You failed',
    ['complete'] = '[Great]Robbery succeeded!',
    ['empty'] = 'The safe is empty',
    ['no_police'] = 'No polices',
    ['rob_key'] = '~r~[E]~s~ Rob',
    ['blip_map'] = 'Shop Robbery(Active)',
    ['alarm_name'] = 'Store Robbery',
    ['triggered'] = 'Alarm triggered!!',
    ['found_item'] = 'You found an item',
    ['found_gun'] = 'You found a gun'
}
