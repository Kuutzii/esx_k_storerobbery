Config = {}

Config.Locale = 'fi'

Config.NotifyPolice = true

Config.Police = 0

Config.Control = 38

Config.Items = {
	'lockpick',
	'cannabis',
	'fixkit'
}

-- 10% mahis saada ase
Config.Guns = {
	[1] = 'WEAPON_BAT',
	[2] = 'WEAPON_KNIFE',
	[3] = 'WEAPON_KNUCKLE'
}

-- ei kannata käyttää vitun buginen ainaki lockpick itemil eli toisin sanoen ei välil anna usettaa/käyttää sitä
Config.EnableItemTrigger = false
Config.LockpickItem = 'lockpick'

Config.Roasdasd = true

Config.donttouch = true -- dont touch 

Config.Cooldown = true -- if false then cooldown is disabled

Config.CooldownSeconds = 1 --how long do you want the cooldown to last

Config.CashMin = 500
Config.CashMax = 1000

Config.SafeLocationss = {
	[1] = {coords = vector3(1734.9, 6420.86, 34.04), name = "24/7 Paleto - 3030", am = 'NIL', lastRobbed = 0},
	[2] = {coords = vector3(1707.85, 4920.40, 41.06), name = "LTD Grapeseed - 2013", cam = 'NIL', lastRobbed = 0},
    [3] = {coords = vector3(1959.31, 3748.90, 31.34), name = "24/7 Sandy Shores - 1036", cam = 'NIL', lastRobbed = 0},
	[4] = {coords = vector3(2672.76, 3286.61, 54.24), name = "LTD Senora Fwy - 957", cam = 'NIL', lastRobbed = 0},
	[5] = {coords = vector3(1169.23, 2717.79, 36.15), name = "Rob's Grand Senora Desert - 940", cam = 'NIL', lastRobbed = 0},
	[6] = {coords = vector3(546.41, 2662.83, 41.15), name = "24/7 Harmony - 928", cam = 'NIL', lastRobbed = 0},
	[7] = {coords = vector3(-3250.00, 1004.38, 11.83), name = "24/7 Chumash - 905", cam = 'NIL', lastRobbed = 0},
	[8] = {coords = vector3(-3047.90, 585.65, 6.90), name = "24/7 Ineseno Road - 804", cam = 'NIL', lastRobbed = 0},
	[9] = {coords = vector3(-2959.58, 387.15, 13.04), name = "Rob's Banham Canyon - 815", cam = 'NIL', lastRobbed = 0},
	[10] = {coords = vector3(-1829.15, 798.79, 137.19), name = "LTD Route 11 - 817", cam = 'NIL', lastRobbed = 0},
	[11] = {coords = vector3(2549.21, 384.85, 107.62), name = "LTD Route 15 - 402", cam = 'NIL', lastRobbed = 0},
	[12] = {coords = vector3(378.19, 333.35, 102.56), name = "24/7 Clinton Avenue - 574", cam = 'NIL', lastRobbed = 0},
	[13] = {coords = vector3(1159.22, -314.0, 68.21), name = "LTD Mirror Park - 411", cam = 'NIL', lastRobbed = 0},
	[14] = {coords = vector3(-1478.95, -375.38, 38.16), name = "Rob's Morningwood - 635", cam = 'NIL', lastRobbed = 0},
	[15] = {coords = vector3(-1220.79, -916.00, 10.32), name = "Rob's Vespucci - 333", cam = 'NIL', lastRobbed = 0},
	[16] = {coords = vector3(1126.83, -980.14, 44.41), name = "Rob's Murrieta Heights - 449", cam = 'NIL', lastRobbed = 0},
	[17] = {coords = vector3(28.21, -1339.22, 28.49), name = "24/7 Strawberry - 125", cam = 'NIL', lastRobbed = 0},
	[18] = {coords = vector3(-43.40, -1748.41, 28.42), name = "LTD Davis - 120", cam = 'NIL', lastRobbed = 0},
}
